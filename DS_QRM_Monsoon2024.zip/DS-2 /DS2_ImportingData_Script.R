#Importing Data ##########

# ABOUT EXCEL FILES ########################################

# From the official R documentation
browseURL("http://j.mp/2aFZUrJ")

# You have been warned: ಠ_ಠ Try to avoid using older Excel versions or better if you use .csv
+
# STEP 1. Set the working directory by going to the preferences

#Step 2 Load the Dataset 

ElectricityAccess_India <- read.csv("~/Desktop/QRM_Monsoon 2024/Dataset/ElectricityAccess_WorldBank_India.csv") # reads and stores data

#Or alternatively, even better set the working directory 

setwd("~/Desktop/QRM_Monsoon 2024/R Code_Monsoon 2024")  # example of setwd() for Mac
#setwd("C:/user/Desktop/DSS") # example for Windows

## Load the dataset
ElectricityAccess_India<- read.csv("ElectricityAccess_WorldBank_India.csv") # reads and stores data

# STEP 3. Looking into the data
dim (ElectricityAccess_India)
View(ElectricityAccess_India) # opens a new tab with contents of dataset. Is this Panel or Time Series or Cross-Sectional? What would happen if I add other South Asian countries to this dataset?  
head(ElectricityAccess_India) # shows the first six rows
head((ElectricityAccess_India), n=3) # shows the first three rows

str(ElectricityAccess_India)  #structure of the object 

#Summary Stats

summary(ElectricityAccess_India)

summary(ElectricityAccess_India$Access_to_electricity)       #summary of Access to Electricity Variable 

## Means_
mean(ElectricityAccess_India$Access_to_electricity) # calculates the mean of Access_to_electricity from 2014 to 2022. $ is a character to access an element in the object. Here it is accessing the variable Access to Elec in the dataset)
mean(ElectricityAccess_India$Access_to_electricity_rural) # calculates the mean of Access to Electricity in Rural Areas from 2014 to 2022

#Now Calculate the mean to the Access to Electricity in Urban Area 

mean (ElectricityAccess_India$Access_to_electricity_urban)
