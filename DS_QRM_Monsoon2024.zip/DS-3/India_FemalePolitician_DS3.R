##DS Session 3 (17th & 18th September 2024): ESTIMATING CAUSAL EFFECTS WITH RANDOMIZED EXPERIMENTS 

###We are trying to explore the relationship between having a female politician having a female politician on the number of new (or repaired) drinking water facilities.

### Do Women Promote Different Policies than Men? (Based on Raghabendra Chattopadhyay and Esther Duflo. 2004. “Women as Policy Makers: Evidence from a Randomized Policy Experiment in India." Econometrica, 72 (5): 1409–43.)

## Set the working directory (according to the final folder you have saved your india.csv file in)
setwd("~/Desktop/QRM_Monsoon 2024/R Code_Monsoon 2024") # example of setwd() for Mac ##This must be the path to the folder where you have the india.csv file store in
#setwd("C:/user/Desktop/DSS") # example for Windows

## Load the dataset
india <- read.csv("india.csv") # reads and stores data

#View the dataset 

View(india)

## Look at the data
head(india) # shows first observations

## Relational operators in R
3==3 # example of a TRUE statement
3==4 # example of a FALSE statement

#How many observations in the dataset? Number of villages: 322

dim(india)

#Mean of the variable female 
mean(india$female)  #34% of the villages in the experiment were randomly assigned to have a female politician. 

#Mean of the variable water 

mean(india$water) #After the randomization of politicians, the average number of new (or repaired) drinking water facilities per village is 18 facilities

mean(india$water[india$female==1]) # mean of water facilities for treatment group

mean(india$water[india$female==0]) # mean of water facilities for control group

## Compute the difference−in−means estimator for female on the outcome variable (water facilities)

mean(india$water[india$female==1]) - mean(india$water[india$female==0])

#Assuming that the villages that were randomly assigned to have a female
#politician were comparable to the villages that were randomly assigned to NOT have a female
#politician (a reasonable assumption since the female politicians were assigned at random), 
#we estimate that having a female politician increases the number of new or repaired drinking water facilities by 9 facilities, on average.

## Compute the difference−in−means estimator for female 

mean(india$irrigation[india$female==1]) - mean(india$irrigation[india$female==0])

#Now interpret this result! 