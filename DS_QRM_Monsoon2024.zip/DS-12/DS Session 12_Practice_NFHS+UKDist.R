###################DS Session 12###########

################################################################################
##NFHS Dataset 
################################################################################

##Read NFHS DATA
################################################################################

nfhs_5<-read.csv('nfhs_5.csv',
                 stringsAsFactors = F)

View (nfhs_5)

################################################################################
##Create New Variables Look at the Codebook
################################################################################
nfhs_5$Children_Stunted<-as.numeric(nfhs_5$I6821_36)

nfhs_5$Improved_Sanitation<-as.numeric(nfhs_5$I6821_96)

nfhs_5$Literacy_Rate <- as.numeric(nfhs_5$I6821_117)

##Scatter Plot 
################################################################################
SanitationRate<-nfhs_5$Improved_Sanitation
StuntingRate<-nfhs_5$Children_Stunted
LiteracyRate<-nfhs_5$Literacy_Rate


Plot1 <- plot(SanitationRate,StuntingRate,main='Scatterplot with Regression Line',
              xlab='Percentage of households using improved sanitation facilities',
              ylab='Incidence of Stunting',xlim=c(0,100))

##plot(x1,y,main='Scatterplot with Regression Line',
#xlab='Literacy Rate',
#ylab='Incidence of Stunting',xlim=c(0,100))

fit <- lm(StuntingRate~SanitationRate) 

abline(fit, col = "blue") #Fit Regression Line  

summary (fit)

#####Evaluate the the t value and p value and comment on the significance#######

##Run Multiple Regression #Urban & #Literacy Rate as a Confounder -- Controlling it.. 

Urban<-ifelse(nfhs_5$TRU=="Urban",1,0)

#Fit Regression Line  
fit2 <- lm(StuntingRate~SanitationRate+LiteracyRate+Urban)  

summary(fit2)

#####Evaluate the the t value and p value and comment on the significance#######

##P Value has gone up for the coefficient of interest (Sanitation vs Stunting) 
####making it difficult for the model to distinguish the unique contribution of each variable. This reduces the statistical power to detect significant effects.


################################################################################
##BREXIT// UK Districts Dataset 
################################################################################

## Load the dataset
dis <- read.csv("UK_districts.csv") # reads and stores data

## Handling missing data
dis1 <- na.omit(dis) # removes observations with NAs
dim(dis1) # provides dimensions (rows, columns) of new dataframe

## Scatter plot
plot(x=dis1$high_education, y=dis1$leave) # creates scatter plot, using names of the arguments 

## Correlation
cor(dis1$high_education, dis1$leave) # calculates correlation between X and Y
cor(dis1$leave, dis1$high_education) # calculates correlation between Y and X  

# Perform correlation test
result <- cor.test(dis1$leave,dis1$high_education, method = "pearson")

# Display results
print(result)

# Extract values from cor.test()
t_value <- result$statistic

z_score <- t_value # For large samples, t approximates z.

z_score

# Calculate the p-value (two-tailed)
p_value <- 2 * (1 - pnorm(abs(z_score)))

p_value

#z-score is very large, which corresponds to an extremely small p-value (close to zero)
##The probability is so small that the pnorm() function rounds it to zero.

summary(lm(leave~high_education,data = dis1))
#####Evaluate the the t value and p value and comment on the significance#######
        