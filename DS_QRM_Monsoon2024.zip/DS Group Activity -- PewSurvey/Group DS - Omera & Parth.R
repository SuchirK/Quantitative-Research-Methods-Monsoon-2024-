setwd("C:/Users/omera/Documents/Datasets_and_Scripts")
pew <- read.csv("Pew_Religion_India_Survey_Data.csv")
head(pew)

#Check Religion
#Label Corruption
pew$corruption_labels <- factor(pew$Q6d,
                                levels = c(1,2,3,4,98,99),
                                labels = c("VBP", "MBP","SP","NOT","IDK","Refuse"))
round(prop.table(table((pew$corruption_labels))),3)
barplot(prop.table(table((pew$corruption_labels))))


#Label Religion
pew$religion_labels <- factor(pew$QRELSING,
                              levels = c(1,2,3,4,5,6,7,8),
                              labels = c("Hindu", "Muslim","Christian","Sikh","Buddhist","Jain","Unknown","None"))

barplot(prop.table(table((pew$religion_labels))))

pt1<- prop.table(table(pew$corruption_labels,pew$religion_labels), margin = 1)
pt2<- prop.table(table(pew$corruption_labels,pew$religion_labels), margin = 2)

round(pt1, 3)

round(prop.table(table(pew$corruption_labels,pew$religion_labels), margin = 2),3)
barplot(pt1, col="blue )

# Generate colors for each unique religion label
bar_colors <- rainbow(length(unique(pew$religion_labels)))

# Correct the custom labels assignment
custom_labels <- c("VBP", "MBP", "SP", "NOT", "IDK", "REFUSE")

# Plot with corrected syntax
barplot(pt, col = bar_colors, beside = FALSE,
        legend.text = custom_labels,
        main = "Proportion of Corruption by Religion",
        xlab = "Corruption Labels",
        ylab = "Proportion")

table(dataset$QRELSING)