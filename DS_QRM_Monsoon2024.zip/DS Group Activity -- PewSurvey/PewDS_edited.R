setwd("D:/Ashoka University/pol/qrm")
pew <- read.csv("Pew_Religion_India_Survey_Data.csv")
View(pew)

pew$Q2_labels<- factor(pew$Q2, levels = c(1,2,3,4,5,6,7, 98,99), 
labels = c(
"Every day",
"More than once a week", 
"Once a week",
"Once or twice a month",
"A few times a year",
"Seldom",
"Never",
"Don’t know",
"Refused"))

pew$QW21a_label <- factor(pew$QW21a, levels = c(1,2,3,4,5, 98,99), 
labels = c(
"Very important", 
"Somewhat important", 
"Not too important", 
"Not at all important", 
"It depends", 
"Don't know", 
"Refused"))

pew$QM21a_label <- factor(pew$QM21a, levels = c(1,2,3,4,5, 98,99), 
labels = c(
"Very important", 
"Somewhat important", 
"Not too important", 
"Not at all important", 
"It depends", 
"Don't know", 
"Refused"))

table(pew$QW21a_label) 

table(pew$QM21a_label)

table(pew$Q2_labels)

barplot(
  rbind(table(pew$QW21a_label), table(pew$QM21a_label)), 
  beside = TRUE, 
  col = c("lightblue", "lightgreen"),
  main = "Importance of Intercaste Marriage",
  xlab = "Importance Ratings", 
  ylab = "Count",
  legend.text = c("Women", "Men"), 
  args.legend = list(x = "topright")
)

table(pew$Q2_labels, pew$QW21a_label)
table(pew$Q2_labels, pew$QM21a_label)

round(prop.table(table(pew$QW21a_label, pew$Q2_labels), margin = 1),2)

round(prop.table(table(pew$Q2_labels, pew$QW21a_label), margin = 2), 2)
barplot(round(prop.table(table(pew$Q2_labels,pew$QW21a_label), margin = 2), 2), 
        beside = TRUE, col = rainbow(9), legend = TRUE, args.legend = list(cex = 0.8, x = "topright"),
        main = "Importance of Intercaste Marriage for Women by News Consumption",
        xlab = "News Consumption Frequency", ylab = "Proportion")

round(prop.table(table(pew$Q2_labels, pew$QM21a_label), margin = 1),2)

round(prop.table(table(pew$Q2_labels, pew$QM21a_label), margin = 2), 2)
barplot(round(prop.table(table(pew$Q2_labels, pew$QM21a_label), margin = 2), 2), 
        beside = TRUE, col = rainbow(9), legend = TRUE, args.legend = list(cex = 0.8, x = "topright"),
        main = "Importance of Intercaste Marriage for Men by News Consumption",
        xlab = "News Consumption Frequency", ylab = "Proportion")

pew_selected <- pew[, c("Q2", "QW21a", "QM21a")]

cor_matrix <- cor(pew_selected, use = "complete.obs")

colnames(cor_matrix) <- c("News Consumption", "Importance (Women)", "Importance (Men)")
rownames(cor_matrix) <- c("News Consumption", "Importance (Women)", "Importance (Men)")

print(cor_matrix)

