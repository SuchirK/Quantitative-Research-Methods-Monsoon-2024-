rm(list=ls())
dataset<-read.csv("Pew_Religion_India_Survey_Data.csv",
                  stringsAsFactors = F)
table(dataset$Q5)
prop.table(table(dataset$Q5))
dataset$economic_labels <- factor(dataset$Q5,
                                  levels = c(1,2,3,98,99),
                                  labels = c("Improve", "Remain the same","Worsen","Don't Know","Refused"))
table(dataset$economic_labels)
dataset$religion_labels <- factor(dataset$QRELSING,
                                  levels = c(1,2,3,4,5,6,7,8),
                                  labels = c("Hindu", "Muslim","Christian","Sikh","Buddhist","Jain","Unknown","None"))
table(dataset$religion_labels)
table_econ_perception <- table(dataset$religion_labels, dataset$economic_labels)
round((prop.table(table_econ_perception, margin=1)), dig=2)
round((prop.table(table_econ_perception, margin=2)), dig=2)
prop_table1 <- round((prop.table(table_econ_perception, margin=1)), dig=2)
prop_table2 <- round((prop.table(table_econ_perception, margin=1)), dig=2)

color <- c("red","blue", "green", "yellow", "pink")

barplot(
  t(prop_table1),
  beside = TRUE,  
  col = color,   
  legend.text = TRUE,
  args.legend = list(x = "topright", bty = "n", cex = 0.6),
  main = "Economic Perceptions by Religion",
  xlab = "Religion",
  ylab = "Proportion",
  ylim = c(0,1)
)
