setwd("C:/Users/vedan/OneDrive - Ashoka University/Desktop/Datasets_and_Scripts")
survey <- read.csv("Pew_Religion_India_Survey_Data.csv")
View(survey)

survey$news <- factor(pew$Q2, levels = c(1,2,3,4,5,6,7, 98,99), 
                      labels = c("Every day","More than once a week", "Once a week","Once or twice a month","A few times a year","Seldom","Never","Don’t know","Refused"))

survey$womencaste <- factor(pew$QW21a, levels = c(1,2,3,4,5, 98,99), 
                            labels = c("Very important", "Somewhat important", "Not too important", "Not at all important", "It depends", "Don't know", "Refused"))

survey$mencaste <- factor(pew$QM21a, levels = c(1,2,3,4,5, 98,99), 
                          labels = c("Very important", "Somewhat important", "Not too important", "Not at all important", "It depends", "Don't know", "Refused"))

table(survey$womencaste) 

table(survey$mencaste)

table(survey$news)

barplot(
  rbind(table(survey$womencaste), table(survey$mencaste)), 
  beside = TRUE, 
  col = c("lightblue", "lightgreen"),
  main = "Importance of Intercaste Marriage",
  xlab = "Importance Ratings", 
  ylab = "Count",
  legend.text = c("Women", "Men"), 
  args.legend = list(x = "topright")
)

table(survey$news, survey$womencaste)
table(survey$news, survey$mencaste)

round(prop.table(table(survey$womencaste, survey$news), margin = 1),2)

round(prop.table(table(survey$news, survey$womencaste), margin = 2), 2)
barplot(round(prop.table(table(survey$news,survey$womencaste), margin = 2), 2), 
        beside = TRUE, col = rainbow(9), legend = TRUE, args.legend = list(cex = 0.8, x = "topright"),
        main = "Importance of Intercaste Marriage for Women by News Consumption",
        xlab = "News Consumption Frequency", ylab = "Proportion")

round(prop.table(table(survey$news, survey$mencaste), margin = 1),2)

round(prop.table(table(survey$news, survey$mencaste), margin = 2), 2)
barplot(round(prop.table(table(survey$news, survey$mencaste), margin = 2), 2), 
        beside = TRUE, col = rainbow(9), legend = TRUE, args.legend = list(cex = 0.8, x = "topright"),
        main = "Importance of Intercaste Marriage for Men by News Consumption",
        xlab = "News Consumption Frequency", ylab = "Proportion")

pew_selected <- survey[, c("Q2", "QW21a", "QM21a")]

cor_matrix <- cor(pew_selected, use = "complete.obs")

colnames(cor_matrix) <- c("News Consumption", "Importance (Women)", "Importance (Men)")
rownames(cor_matrix) <- c("News Consumption", "Importance (Women)", "Importance (Men)")

print(cor_matrix)

