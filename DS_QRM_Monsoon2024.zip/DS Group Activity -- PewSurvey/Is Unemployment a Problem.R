rm(list=ls())
dataset<-read.csv("Pew_Religion_India_Survey_Data.csv",
                  stringsAsFactors = F)
table(dataset$Q6a)
prop.table(table(dataset$Q6a))
dataset$unemployment <- factor(dataset$Q6a,
                                  levels = c(1,2,3,4,98,99),
                                  labels = c("Very Big Problem", "Moderately Big Problem","Small Problem","Not a Problem", "Don't Know", "Refused"))
table(dataset$unemployment)
dataset$religion_labels <- factor(dataset$QRELSING,
                                  levels = c(1,2,3,4,5,6,7,8),
                                  labels = c("Hindu", "Muslim","Christian","Sikh","Buddhist","Jain","Unknown","None"))
table(dataset$religion_labels)
table_unemploy_percep <- table(dataset$religion_labels, dataset$unemployment)
round((prop.table(table_unemploy_percep, margin=1)), dig=2)
round((prop.table(table_unemploy_percep, margin=2)), dig=2)
prop_table1 <- round((prop.table(table_unemploy_percep, margin=1)), dig=2)
prop_table2 <- round((prop.table(table_unemploy_percep, margin=2)), dig=2)

color <- c("red","blue", "green", "yellow", "pink", "cyan")

barplot(
  t(prop_table1),
  beside = TRUE,  
  col = color,   
  legend.text = TRUE,
  args.legend = list(x = "topright", bty = "n", cex = 0.6),
  main = "Unemployment is a Probelem?",
  xlab = "Religion",
  ylab = "Proportion",
  ylim = c(0,1)
)