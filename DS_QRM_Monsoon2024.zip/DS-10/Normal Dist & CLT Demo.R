########################################################################################

##Normal Distribution, Law of Large Numbers and CLT Demo (DS Session 10)

#######################################################################################

# Define mean and standard deviation
mean <- 0
sd <- 1
# Generate a sequence of x values from -4 to 4
x <- seq(-4, 4, length = 1000)

View (x)

# Calculate the density (height) of the Normal Distribution for each x
y <- dnorm(x,mean, sd)

# Plot the Standard Normal Distribution
plot(x, y, type = "l", col = "blue", lwd = 2,
     main = "Standard Normal Distribution (Mean = 0, SD = 1)",
     xlab = "Value", ylab = "Density")

pnorm(2, mean = 5, sd = 4) 

1-pnorm(2, mean = 5, sd = 4)


########################################################################################

##Generating Random Samples from the Normal Distribution

#######################################################################################

# Set seed for reproducibility 
set.seed(42) #create random numbers that can be reproduced

# Generate 1000 random samples with mean = 5, sd = 2
random_samples <- rnorm(1000, mean = 5, sd = 2)

View (random_samples)

# Plot a histogram of the random samples
hist(random_samples, breaks = 500, col = "lightblue",
     main = "Histogram of Random Samples (Mean = 5, SD = 2)",
     xlab = "Value", border = "black")

# Calculate the probability of a value being less than 1.5 
p <- pnorm(1.5, mean = 5, sd = 2)
cat("P(X < 1.5):", p, "\n") ##Cat is simply used display the output in a certain format... \n means that take that value held in variable p and display it..

# Calculate the probability of a value being between -1 and 1 according to the standard normal
p_between <- pnorm(1, mean = 0, sd = 1) - pnorm(-1, mean = 0, sd = 1)
cat("P(-1 < X < 1):", p_between, "\n")


# Calculate the probability of a value being between -2 and 2 according to the standard normal
p_between2 <- pnorm(2, mean = 0, sd = 1) - pnorm(-2, mean = 0, sd = 1)
cat("P(-2 < X < 2):", p_between2, "\n")

p_between3 <- pnorm(3, mean = 0, sd = 1) - pnorm(-3, mean = 0, sd = 1)
cat("P(-3 < X < 3):", p_between3, "\n")


# Calculate the probability of a value being between -1 and 1 according to a normal
p_between3 <- pnorm(4, mean = 0, sd = 2) - pnorm(-4, mean = 0, sd = 2) ##1 standard deviation from the mean
cat("P(-4 < X < 4):", p_between3, "\n")


########################################################################################

##Showing 68-95-99.7 Rule

#######################################################################################

# Calculate probabilities using pnorm()
within_1_sd <- pnorm(1, mean, sd) - pnorm(-1, mean, sd)
within_2_sd <- pnorm(2, mean, sd) - pnorm(-2, mean, sd)
within_3_sd <- pnorm(3, mean, sd) - pnorm(-3, mean, sd)

# Display the results
cat("Probability within 1 SD (68%):", round(within_1_sd * 100, 2), "%\n")
cat("Probability within 2 SDs (95%):", round(within_2_sd * 100, 2), "%\n")
cat("Probability within 3 SDs (99.7%):", round(within_3_sd * 100, 2), "%\n")

##This demonstrates that approximately 68% of the data falls within 1 standard deviation of the mean, 95% within 2 standard deviations, and 99.7% within 3 standard deviations.

########################################################################################

##Law of Large Numbers 

#######################################################################################
# Set seed for reproducibility 
set.seed(30) #create random numbers that can be reproduced

# Define the population parameters
population_mean <- 50
population_sd <- 10

# Number of samples to generate in total
##Assumption: Each sample has 1 value
n_samples <- 10000

# Generate a large set of random numbers from the normal distribution
samples <- rnorm(n_samples, mean = population_mean, sd = population_sd)

# Initialize a vector to store the cumulative mean
cumulative_means <- numeric(n_samples)


# Calculate the cumulative mean for each increasing sample size
for (i in 1:n_samples) {
  cumulative_means[i] <- mean(samples[1:i])
}

# Print out sample means at specific sample sizes
cat("Sample Mean after 10 samples: ", round(cumulative_means[10], 2), "\n")
cat("Sample Mean after 100 samples: ", round(cumulative_means[100], 2), "\n")
cat("Sample Mean after 1,000 samples: ", round(cumulative_means[1000], 2), "\n")
cat("Sample Mean after 10,000 samples: ", round(cumulative_means[10000], 2), "\n")

# Display the population mean for comparison
cat("True Population Mean: ", population_mean, "\n")

####Another simpler example

Sample_1 <- rnorm (10, mean =67, sd= sqrt(14)) #Population mean is 67, Popularion variance is 14 , Sample size is 10

View (Sample_1)

mean (Sample_1)

Sample_2 <- rnorm (1000, mean =67, sd= sqrt(14)) #Population mean is 67, Popularion variance is 14 , Sample size is 1000

mean (Sample_2)

Sample_3<- rnorm (1000000, mean =67, sd= sqrt(14))

mean (Sample_3)

########################################################################################

#####Demonstrate Central Limit Theorem 

##Here we are making a certain number of samples with a sample size 

#######################################################################################


# Step 1: Generate a population with a non-normal distribution (Uniform distribution)
population_size <- 100000
population <- runif(population_size, min = 0, max = 100)  # Uniform distribution between 0 and 100 ##runif() generates random numbers from a uniform distribution

hist(
  population,
  col = "lightblue",
  main = "Population Distribution",
  freq = FALSE
)


View (population)

# Step 2: Define parameters for sampling
n_samples <- 10000# Number of samples we'll take
sample_size <- 100  # Size of each sample

# Step 3: Take multiple samples and calculate their means
sample_means <- numeric(n_samples)
for (i in 1:n_samples) {
  sample <- sample(population, sample_size, replace = TRUE)
  sample_means[i] <- mean(sample)
}

# Step 4: Display results
cat("Mean of the original population: ", round(mean(population), 2), "\n")
cat("Standard deviation of the original population: ", round(sd(population), 2), "\n")
cat("Mean of the sample means: ", round(mean(sample_means), 2), "\n")
cat("Standard deviation of the sample means: ", round(sd(sample_means), 2), "\n")
cat("Expected standard deviation of sample means (σ/sqrt(n)): ", round(sd(population) / sqrt(sample_size), 2), "\n") 

##Play around with the n_sample and sample size and see how the expected standard deviation of sample means is changing (the standard error)


# Step 5: Plot the distribution of the sample means
hist(
  sample_means,
  breaks = 30,
  col = "lightblue",
  main = "Distribution of Sample Means (n = 100)",
  xlab = "Sample Means",
  freq = FALSE
)

##It's a normal distribution!

# Step 6: Overlay the normal distribution curve
x_values <- seq(min(sample_means), max(sample_means), length.out = 100)
y_values <- dnorm(x_values, mean = mean(sample_means), sd = sd(sample_means))

lines(x_values, y_values, col = "red", lwd = 2)




