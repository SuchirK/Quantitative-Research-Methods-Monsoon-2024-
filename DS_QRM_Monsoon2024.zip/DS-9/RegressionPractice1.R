###############################################################################
##All India NFHS 
###############################################################################

rm(list=ls())

library(stargazer)


##Read NFHS DATA
################################################################################

nfhs_5<-read.csv('nfhs_5.csv',
         stringsAsFactors = F)

View (nfhs_5)
################################################################################
##Create New Variables Look at the Codebook
################################################################################
nfhs_5$Children_Stunted<-as.numeric(nfhs_5$I6821_36)

nfhs_5$Improved_Sanitation<-as.numeric(nfhs_5$I6821_96)

nfhs_5$Literacy_Rate <- as.numeric(nfhs_5$I6821_117)



################################################################################
##Scatter Plot 
################################################################################
x<-nfhs_5$Improved_Sanitation
y<-nfhs_5$Children_Stunted
x1<-nfhs_5$Literacy_Rate


plot(x,y,main='Scatterplot with Regression Line',
     xlab='Percentage of households using improved sanitation facilities',
     ylab='Incidence of Stunting',xlim=c(0,100))

plot(x1,y,main='Scatterplot with Regression Line',
       xlab='Literacy Rate',
       ylab='Incidence of Stunting',xlim=c(0,100))

#Fit Regression Line  
fit <- lm(y~x) 

fit1 <- lm(y~x1) 

################################################################################
##Add the regression line to the plot
################################################################################

plot
abline(fit,col="red")


################################################################################
##Bi Variate regression results
################################################################################

summary(fit)

#summary text
summary_text<-capture.output(summary(fit))

#save output
writeLines(summary_text,'Reg_1.txt')


################################################################################
##Run Multiple Regression #Urban as a Confounder -- Controlling it.. 
################################################################################

z<-ifelse(nfhs_5$TRU=="Urban",1,0)

#Fit Regression Line  
fit2 <- lm(y~x+z)  

summary(fit2)

#summary text
summary_text<-capture.output(summary(fit2))

#save output
writeLines(summary_text,'Reg_2.txt')

################################################################################
##Now, let's look at Literacy Rate and Children Stunting w.o control
################################################################################

LiteracyRate <- nfhs_5$Literacy_Rate
y <- nfhs_5$Children_Stunted

# Plot scatterplot with labels and limits
plot(LiteracyRate, y, 
     main = 'Scatterplot with Regression Line',
     xlab = 'Literacy Rate',
     ylab = 'Incidence of Stunting', 
     xlim = c(0, 100))

# Fit the linear model
fit_LitRate_Stunting <- lm(y ~ LiteracyRate)

# Add the regression line to the plot
abline(fit_LitRate_Stunting, col = "red")

# Display the summary of the linear model
summary(fit_LitRate_Stunting)

stargazer(fit_LitRate_Stunting, style = 'qje') ##In latex format. Now take the output and put it into a Latex Converter online

##A Quick Latex Reader: https://texviewer.herokuapp.com/

# Capture summary text output
summaryofLitRate_Stunting_text <- capture.output(summary(fit_LitRate_Stunting))

writeLines(summaryofLitRate_Stunting_text,'Reg_2.txt')

################################################################################
##Run Multiple Regression #Urban as a Confounder -- Controlling it.. by adding to the above framework: Literacy Rate & Stunting Rate 
################################################################################

Urban<-ifelse(nfhs_5$TRU=="Urban",1,0)

#Fit Regression Line  
fit_control <- lm(y~LiteracyRate+Urban)  

summary(fit_control)

stargazer(fit_control, style = 'qje')









