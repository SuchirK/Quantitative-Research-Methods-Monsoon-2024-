###############################################################################
##All India NFHS 
###############################################################################

rm(list=ls())

library(stargazer)


##Read NFHS DATA
################################################################################

nfhs_5<-read.csv('nfhs_5.csv',
         stringsAsFactors = F)

View (nfhs_5)
################################################################################
##Create New Variables Look at the Codebook
################################################################################
nfhs_5$Children_Stunted<-as.numeric(nfhs_5$I6821_36)

nfhs_5$Improved_Sanitation<-as.numeric(nfhs_5$I6821_96)

nfhs_5$Literacy_Rate <- as.numeric(nfhs_5$I6821_117)



################################################################################
##Scatter Plot 
################################################################################
SanitationRate<-nfhs_5$Improved_Sanitation
StuntingRate<-nfhs_5$Children_Stunted
LiteracyRate<-nfhs_5$Literacy_Rate


Plot1 <- plot(SanitationRate,StuntingRate,main='Scatterplot with Regression Line',
     xlab='Percentage of households using improved sanitation facilities',
     ylab='Incidence of Stunting',xlim=c(0,100))

##plot(x1,y,main='Scatterplot with Regression Line',
       #xlab='Literacy Rate',
       #ylab='Incidence of Stunting',xlim=c(0,100))

#Fit Regression Line  
fit <- lm(StuntingRate~SanitationRate) 

fit1 <- lm(y~x1) 

################################################################################
##Add the regression line to the plot
################################################################################

Plot1
abline(fit,col="red")


################################################################################
##Bi Variate regression results
################################################################################

summary(fit)

#summary text
summary_text<-capture.output(summary(fit))

#save output
writeLines(summary_text,'Reg_1.txt')


################################################################################
##Run Multiple Regression #Urban & #Literacy Rate as a Confounder -- Controlling it.. 
################################################################################

Urban<-ifelse(nfhs_5$TRU=="Urban",1,0)

#Fit Regression Line  
fit2 <- lm(StuntingRate~SanitationRate+LiteracyRate+Urban)  

summary(fit2)

stargazer(fit2, style = 'qje')

##A Quick Latex Reader: https://texviewer.herokuapp.com/










