#The very basics of R - follow along code 
#Course: Week 1 & 2 of QRM | Fall 2024

#Think of R as a fancy calculator with a lot of tricks and shortcuts

3+4 #Has given me 7 in a giffy 

x <- 3+4

#Now let's go over variables 

## Admittedly, adding individual numbers, can be done through an actual  calculator or even your brain. 
###Sometimes though, you might want to reuse a specific number over and over again. 
##For example, if you want to find out how many yards there are in a meter, you have to multiply meters*1.0936. 
#Rather than typing 1.0936 every time we can simply turn it into a variable! For example:

yard_conversion <-  1.0936 ##copy+paste this into the console below or you could just select and run. 

#Shortcut for <- is Option+- (Mac) or Alt + - (Windows )

#You'll note that yard_conversion just appeared in the top-right "environment" window 
#This is where R shows you the variables. For reasons that will become clear, this is very, very useful. 
#Now let's math! Say we are taking a penalty in football and we're in the US, we'd have to measure in yards. 
#We can make this calculation by using the conversion variable.
#Penalty kick is taken from a penalty spot that is 11 meters

11*yard_conversion

#We can also use the variable for more complicated formulas. Let's say you want
#to know the area of a circle in yards, but you only know the radius is 23 meters.
#We can do that like so:

pi*(23*yard_conversion)^2 #Area of circle in yards

#Coding Hygiene: Saving your work! 

#You want to be able to save your work. R stores your code in "scripts." This is the
#sequence of all the code. Whenever you start a new project, you should open up a
#new script and save it. You can name it whatever you want, but the best naming
#convention is all lower case with an _ for a space. Do not put a space in your
#file name. A space is a special character and can pose to be an issue when moving to
#different data formats.

#Now Save this as R_DS1_Level1 

