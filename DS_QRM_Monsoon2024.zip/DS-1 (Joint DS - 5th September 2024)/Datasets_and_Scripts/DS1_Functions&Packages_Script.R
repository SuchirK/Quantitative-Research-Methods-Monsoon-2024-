#R_DS_Level2

#Now, let's say you work for you are working for a Car Tyre company and you're constantly entering this formula. 
#It gets pretty tedious. You want to be able to plug in the meters and get the result. To do this we can create a
#function. A function is a little piece of code that will take an input
#(variable/argument) and give (return) and output.


AreaYards <- function (meters){
  
  return(pi*(meters*yard_conversion)^2)
  
}

#AreaYards is the name of the function. The word 'function (in pink)' is a
#"reserved word" that is part of the syntax of R. Essentially, it tells R you
#want to create a function, much like the + operator tells it you want to add
#things. In the parenthesis is the variable (argument) that you are going to put
#in. It can have any name, but obviously it is useful to name it something that
#gives an indication as to what it is. Between the curly brackets is the "guts"
#of the function.This is where you take the variable that was entered and
#perform an operation on it. It then returns the result of that operation.

#Now that our function is made let's run it:

AreaYards(23) #Radius is 23 metres

#What makes R so powerful is that it has a lot of really useful functions for
#doing data science. In all likelihood you won't be writing any of your own
#functions, but borrowing what other people have already done through the use of Packages. Base R has a lot
#of built in functions, but these can be expanded through "packages", bundles of
#functions that a good-Samaritan has created to make your life easier. We'll
#talk about this in a few.

#For example, if you want to get the current time that's actually a pretty
#involved process, because you have to access the system time on the operating
#system. Fear not, there's function:

Sys.Date()

#Sys.Date() and Sys.Time() are very useful for giving your output a time stamp.

seq(1:10) #in R a number with a colon means a range of values. Function for sequence from 1 to 10. 

AreaYards(seq(1:10)) #Nested function

#I can even pass multiple arguments in the same function.

AreaYards(seq(from = 5, to =25, by=5))

#How did I know seq() can take multiple arguments? Use the R help. typing ? and
#the function name will bring up the R help file (i.e. ?seq).

?seq

AreaYards(seq(5,25,5))

#Wait, what's the sequence seq (5,25,5)? When confused, might as well just the run the code 

seq(5,25,5)

#I can nest even more

max(AreaYards(seq(5,25, by=5))) #Get the maximum value
min(AreaYards(seq(5,25, by=5))) #Get the minimum value


mean(c(max(AreaYards(seq(5,25, by=5))),min(AreaYards(seq(5,25, by=5))))) 
#Make a vector of the min/max and then calculate the mean. There is no reason to do this this way.

#That's alot of parenthesis. This becomes very confusing very quickly. Avoid this.
#Your code should be readable by others. This is called "literate programming," -- book (Stanford)
#and for the purposes of academia it is extremely important. 
#Code should written in such a way that when someone can step into your code and navigate it, even if they are not intimately
#familiar with the language. This is one key features of using programming for
#academic research.

#Let's clean the code a bit 

circle_areas <- AreaYards(seq(5,25, by=5))
circle_areas_max <- max(circle_areas)
circle_areas_min <- min(circle_areas)
circle_areas_min_max <- c(circle_areas_min, circle_areas_max) #c(a,b,c...) concatenates values
circle_areas_mean <- mean(circle_areas_min_max)

#This code is a bit unneccessarily verbose!

#Too many steps, and most of the are for creating intermediate variables that serve no purpose other than the final
#calculation. This happens a lot in R. So a good fellow named Hadley Wickham came 
#along and with a team of coders made the "tidyverse" package. This is a package
#used to do common data manipulations in R more efficiently. To know more about Hadley, visit https://hadley.nz/
#It is also a framework (dialect) of the R language meant to make it cleaner and more
#readable.

install.packages("tidyverse")

library (tidyverse) #load package

circle_areas <- AreaYards(seq(5,25,5))
circle_areas_mean2 <-  c(min(circle_areas),
                         max(circle_areas)) %>%
  mean()

# You notice the strange %>% (pipe) symbol. This basically this means "and then."
# Thus, this line of code says concatenate the min and max values and then give
# the mean. with dplyr (part of tidyverse) you can pipe through a bunch of
# functions without reading them into variables or nesting them. It makes for
# clearer reading especially if you are piping through quite a number of
# commands.










